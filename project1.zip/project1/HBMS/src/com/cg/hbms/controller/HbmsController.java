package com.cg.hbms.controller;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import com.cg.hbms.beans.BookingDetails;
import com.cg.hbms.beans.Hotels;
import com.cg.hbms.beans.RoomDetails;
import com.cg.hbms.beans.Users;
import com.cg.hbms.exception.HbmsException;
import com.cg.hbms.service.HbmsServiceImpl;
import com.cg.hbms.service.IHbmsService;

@WebServlet("*.hb")
public class HbmsController extends HttpServlet 
{
	IHbmsService service = null;
	
@Override
public void init() throws ServletException {
	
	service = new HbmsServiceImpl();
}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{	
		processRequest(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		processRequest(request, response);
	}

	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		
		String action = request.getServletPath();	
		IHbmsService servObj = new HbmsServiceImpl();
		
		RequestDispatcher rd = null;
		
		switch (action)
		{
		case "/addUser.hb":														//for Adding user details to Database
			String userName = request.getParameter("userName");
			String mobileNumber =request.getParameter("mobileNumber");
			String phone = request.getParameter("phone");
			String password = request.getParameter("password");
			String address = request.getParameter("address");
			String email = request.getParameter("email");
			String role = request.getParameter("role");
			
			Users user = new Users();
			
			user.setPassword(password);
			user.setRole(role);
			user.setUserName(userName);
			user.setMobileNumber(mobileNumber);;
			user.setPhoneNumber(phone);
			user.setAddress(address);
			user.setEmail(email);
	
			try 
			{
				servObj.addUSer(user);
			} catch (HbmsException e) 
			{
				request.getSession().setAttribute("error", e.getMessage());
				//e.printStackTrace();
			}
			
			HttpSession session = request.getSession();
			session.setAttribute("user",user);
			
			RequestDispatcher reqDis = getServletContext().getRequestDispatcher("/searchhotel.jsp");
			
		     reqDis.forward(request, response);
			
			break;
			
		case "/viewusers.hb":
			System.out.println("reached");
			List<Users> myList = null;
			try 
			{
				myList = service.showAll();
				request.getSession().setAttribute("list", myList);
				System.out.println(myList);
				rd = request.getRequestDispatcher("viewusers.jsp");
				rd.forward(request, response);
				
			}
			catch (HbmsException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				request.getSession().setAttribute("message", e.getMessage());
			}

			
			break;
			
		case "/addHotel.hb":
			String city = request.getParameter("city");
			String hotelName =request.getParameter("hotelName");
			String addressHotel = request.getParameter("address");
			String description = request.getParameter("description");
			Double nightRate = (Double.parseDouble(request.getParameter("nightRate")));
			String phoneOne = request.getParameter("phoneOne");
			String phoneTwo = request.getParameter("phoneTwo");
			String rating = request.getParameter("rating");
			String emailHotel = request.getParameter("email");
			String fax = request.getParameter("fax");
			
			Hotels hotel = new Hotels();
			
			hotel.setCity(city);
			hotel.setHotelName(hotelName);
			hotel.setAddress(addressHotel);
			hotel.setDescription(description);;
			hotel.setNightRate(nightRate);
			hotel.setPhoneOne(phoneOne);
			hotel.setPhoneTwo(phoneTwo);
			hotel.setRating(rating);;
			hotel.setEmail(emailHotel);
			hotel.setFax(fax);
			
			try 
			{
				servObj.addHotel(hotel);
			} catch (HbmsException e) 
			{
				request.getSession().setAttribute("error", e.getMessage());
				//e.printStackTrace();
			}
			
			HttpSession sessionH = request.getSession();
			sessionH.setAttribute("hotel",hotel);
			
			RequestDispatcher reqDisH = getServletContext().getRequestDispatcher("/success.jsp");
			
		    reqDisH.forward(request, response);
			break;
			
		case "/viewhotels.hb":
			System.out.println("reached");
			List<Hotels> myListH = null;
			try 
			{
				myListH = service.showAllHotels();
				request.getSession().setAttribute("listH", myListH);
				System.out.println(myListH);
				rd = request.getRequestDispatcher("viewhotels.jsp");
				rd.forward(request, response);
				
			}
			catch (HbmsException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				request.getSession().setAttribute("message", e.getMessage());
			}

			break;
			
		case "/addRoom.hb":
			int hotelId = (Integer.parseInt(request.getParameter("hotelId")));
			String roomNo =request.getParameter("roomNo");
			String roomType = request.getParameter("roomType");
			String perNightRate = request.getParameter("perNightRate");
			Boolean availability = (Boolean.parseBoolean(request.getParameter("availability")));
			
			RoomDetails room = new RoomDetails();
			
			room.setHotelId(hotelId);
			room.setRoomNo(roomNo);
			room.setRoomType(roomType);
			room.setPerNightRate(perNightRate);
			room.setAvailability(availability);
			
			try 
			{
				servObj.addRoomDetails(room);
			} catch (HbmsException e) 
			{
				request.getSession().setAttribute("error", e.getMessage());
				//e.printStackTrace();
			}
			
			HttpSession sessionR = request.getSession();
			sessionR.setAttribute("room",room);
			
			RequestDispatcher reqDisR = getServletContext().getRequestDispatcher("/success.jsp");
			
		    reqDisR.forward(request, response);
			
		    break;
			
		case "/viewrooms.hb":
			System.out.println("reached");
			List<RoomDetails> myListR = null;
			try 
			{
				myListR = service.showAllRooms();
				request.getSession().setAttribute("listR", myListR);
				System.out.println(myListR);
				rd = request.getRequestDispatcher("viewrooms.jsp");
				rd.forward(request, response);
				
			}
			catch (HbmsException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				request.getSession().setAttribute("message", e.getMessage());
			}
			
			break;
			
		case "/addBooking.hb":
			
			System.out.println("In Controller");
			
			String dateFrom = request.getParameter("bookedFrom");
			String dateTo = request.getParameter("bookedTo");
			
			SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
			  
			 Date dateF=null;
			 Date dateT=null;
			 
			try {
				dateF = formatter.parse(dateFrom);
				dateT = formatter.parse(dateTo);
			} 
			catch (ParseException e) 
			{
				e.printStackTrace();
			}
			 
			 java.sql.Date bookedFrom = new java.sql.Date(dateF.getTime());
			 java.sql.Date bookedTo = new java.sql.Date(dateT.getTime());
			
			int roomId = (Integer.parseInt(request.getParameter("roomId")));
			int userId =(Integer.parseInt(request.getParameter("userId")));
			int noOfAdults = (Integer.parseInt(request.getParameter("noOfAdults")));
			int noOfChildren = (Integer.parseInt(request.getParameter("noOfChildren")));
			int amount = (Integer.parseInt(request.getParameter("amount")));
			
			BookingDetails book = new BookingDetails();
			
			book.setRoomId(roomId);
			book.setUserId(userId);
			book.setBookedFrom(bookedFrom);
			book.setBookedTo(bookedTo);
			book.setNoOfAdults(noOfAdults);
			book.setNoOfChildren(noOfChildren);
			book.setAmount(amount);
			
			try 
			{
				servObj.addBookingDetails(book);
			} catch (HbmsException e) 
			{
				request.getSession().setAttribute("error", e.getMessage());
				//e.printStackTrace();
			}
			
			HttpSession sessionB = request.getSession();
			sessionB.setAttribute("book",book);
			
			RequestDispatcher reqDisB = getServletContext().getRequestDispatcher("/success.jsp");
			
		    reqDisB.forward(request, response);
			
		    break;
			
		case "/viewbookings.hb":
			List<BookingDetails> myListB = null;
			try 
			{
				myListB = service.showAllBookings();
				request.getSession().setAttribute("listB", myListB);
				System.out.println(myListB);
				rd = request.getRequestDispatcher("viewbookings.jsp");
				rd.forward(request, response);
				
			}
			catch (HbmsException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				request.getSession().setAttribute("message", e.getMessage());
			}

			break;
			
		case "/searchhotelcity.hb":
			String citySh = request.getParameter("citysh");
			
			Hotels hotelc = new Hotels();
			hotelc.setCity(citySh);
			
			List<Hotels> myListSh = null;
			try 
			{
				myListSh = service.searchHotels(citySh);
				request.getSession().setAttribute("listSh", myListSh);
				System.out.println(myListSh);
				rd = request.getRequestDispatcher("searchbycity.jsp");
				rd.forward(request, response);
				
			}
			catch (HbmsException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				request.getSession().setAttribute("message", e.getMessage());
			}
			break;
			
		case "/updatehotelcity.hb":
			
			
			int hotelId1 = (Integer.parseInt(request.getParameter("hotelId")));
			String city1 = request.getParameter("city");
			String hotelName1 =request.getParameter("hotelName");
			String addressHotel1 = request.getParameter("address");
			String description1 = request.getParameter("description");
			Double nightRate1 = (Double.parseDouble(request.getParameter("nightRate")));
			String phoneOne1 = request.getParameter("phoneOne");
			String phoneTwo1 = request.getParameter("phoneTwo");
			String rating1 = request.getParameter("rating");
			String emailHotel1 = request.getParameter("email");
			String fax1 = request.getParameter("fax");
			
			
			hotel = new Hotels(hotelId1,city1 , hotelName1,addressHotel1, description1 , nightRate1, phoneOne1, phoneTwo1, rating1,  emailHotel1, fax1 );
			hotel.setCity(city1);
			try 
			{
				service.updateHotels(hotel);
				rd = request.getRequestDispatcher("updatebycity.jsp");
				rd.forward(request, response);
				
			} 
			catch (HbmsException e1) {
				request.getSession().setAttribute("error", e1.getMessage());
				e1.printStackTrace();
			}
			
		default:
			break;
		}
	}
}

