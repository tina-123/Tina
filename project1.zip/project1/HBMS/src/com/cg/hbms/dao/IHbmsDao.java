package com.cg.hbms.dao;

import java.util.List;

import com.cg.hbms.beans.BookingDetails;
import com.cg.hbms.beans.Hotels;
import com.cg.hbms.beans.RoomDetails;
import com.cg.hbms.beans.Users;
import com.cg.hbms.exception.HbmsException;

public interface IHbmsDao 
{
	public int addUSer(Users user) throws HbmsException;
	
	List<Users> showAll() throws HbmsException;
	
	public int addHotel(Hotels hotel) throws HbmsException;
	
	List<Hotels> showAllHotels() throws HbmsException;
	
	public int addRoomDetails(RoomDetails room) throws HbmsException;
	
	List<RoomDetails> showAllRooms() throws HbmsException;
	
	public int addBookingDetails(BookingDetails book) throws HbmsException;
	
	List<BookingDetails> showAllBookings() throws HbmsException;
	
	List<Hotels> searchHotels(String city) throws HbmsException;
	
	public void updateHotels(Hotels hotel) throws HbmsException;
}
