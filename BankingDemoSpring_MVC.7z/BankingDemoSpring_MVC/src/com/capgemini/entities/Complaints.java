package com.capgemini.entities;

import java.sql.Date;

public class Complaints
{
	private int cid;
	private Date cDate;
	private String title;
	private String category;
	private String level;
	private String status;
	
	public Complaints() 
	{
		super();
	}

	public Complaints(int cid, Date cDate, String title, String category,
			String level, String status) {
		super();
		this.cid = cid;
		this.cDate = cDate;
		this.title = title;
		this.category = category;
		this.level = level;
		this.status = status;
	}

	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public Date getcDate() {
		return cDate;
	}

	public void setcDate(Date cDate) {
		this.cDate = cDate;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Complaints [cid=" + cid + ", cDate=" + cDate + ", title="
				+ title + ", category=" + category + ", level=" + level
				+ ", status=" + status + "]";
	}
	
	
	
	

}
