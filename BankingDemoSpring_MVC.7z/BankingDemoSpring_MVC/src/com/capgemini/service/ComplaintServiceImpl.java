package com.capgemini.service;

import java.util.List;

import com.capgemini.entities.Complaints;
import com.capgemini.exception.ComplaintException;

public class ComplaintServiceImpl implements IComplaintService {

	@Override
	public int addComplaints(Complaints complaints) throws ComplaintException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Complaints> getComplaints() throws ComplaintException {
		// TODO Auto-generated method stub
		return null;
	}

}
