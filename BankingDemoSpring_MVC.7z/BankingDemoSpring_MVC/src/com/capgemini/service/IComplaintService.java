package com.capgemini.service;

import java.util.List;

import com.capgemini.entities.Complaints;
import com.capgemini.exception.ComplaintException;

public interface IComplaintService
{


	public int addComplaints(Complaints complaints) throws ComplaintException;
	public List<Complaints> getComplaints()throws ComplaintException;
}
