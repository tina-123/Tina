package com.capgemini.dao;

import java.util.List;

import com.capgemini.entities.Complaints;
import com.capgemini.exception.ComplaintException;

public interface IComplaintsDao
{
	public int addComplaints(Complaints complaints) throws ComplaintException;
	public List<Complaints> getComplaints()throws ComplaintException;

}
