package com.capgemini.dao;

import java.util.List;
import java.util.concurrent.CompletionException;

import com.capgemini.entities.Complaints;

public class ComplaintDaoImpl implements IComplaintsDao {

	@Override
	public int addComplaints(Complaints complaints) throws CompletionException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<Complaints> getComplaints() {
		// TODO Auto-generated method stub
		return null;
	}

}
