package com.capgemini.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.capgemini.dto.ShowDetails;
import com.capgemini.exception.ShowDetailException;
import com.capgemini.service.IShowDetailService;
import com.capgemini.service.ShowDetailServiceImpl;


@WebServlet(urlPatterns= {"/TicketController","/getShowDetails","/BookNow"})
public class TicketController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	ServletConfig conf;
	IShowDetailService showDetailService;
  
    public TicketController() 
    {
    	showDetailService=new ShowDetailServiceImpl();
    }

	public void init(ServletConfig config) throws ServletException 
	{
	
	}

	
	public void destroy()
	{
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request, response);
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	
	{
		
		String path=request.getServletPath();
		System.out.println(path);
		String url="";
		HttpSession session;
		
		switch(path)
		{
		case"/TicketController":
			System.out.println("inside controller");
			List<ShowDetails> sdList=showDetailService.getShowDetails();
			request.setAttribute("sdList", sdList);
			url="ShowDetails.jsp";
			break;
			
		case "/getShowDetails":
			System.out.println("getting Show Details");
			String showId=request.getParameter("showId");
			ShowDetails show=showDetailService.getShowDetails(showId);
			request.setAttribute("show", show);
			url="BookNow.jsp";
			
			break;
			
		case "/BookNow":
			System.out.println("inside book now");
			String showName = request.getParameter("txtShowName");
			double price = Double.parseDouble(request.getParameter("txtPrice")) ;
			String customerName = request.getParameter("txtCustName");
			long mob =Long.parseLong(request.getParameter("txtMobile"));
			int availSeats = Integer.parseInt(request.getParameter("txtSeatAvl"));
			int noOfSeats = Integer.parseInt(request.getParameter("txtNoOfSeats"));
			System.out.println(noOfSeats);
			
			if(noOfSeats == 0 || noOfSeats < 0)
			{
				throw new ShowDetailException("Please Enter valid no of seats");
			}
			
			if(availSeats < noOfSeats)
			{
				throw new ShowDetailException("Please Enter valid no of seats");
			}
			else
			{
				int updatedSeats = availSeats-noOfSeats ;
				request.setAttribute("showname", showName);
				request.setAttribute("cname", customerName);
				request.setAttribute("mobileNo", mob);
				request.setAttribute("noOfSeats", noOfSeats);
				double totalPrice = price * noOfSeats ;
				request.setAttribute("totalPrice", totalPrice);
				showDetailService.ShowDetails(updatedSeats , showName);
				url = "sucess.jsp" ;
			}
			
			break ;

			
			
			
			
			default:
				break;
		}
		RequestDispatcher rd=request.getRequestDispatcher(url);
		rd.forward(request, response);
	
		
	}

}
