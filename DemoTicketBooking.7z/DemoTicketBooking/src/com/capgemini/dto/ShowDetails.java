package com.capgemini.dto;

import java.sql.Date;

public class ShowDetails 
{
 
	private String showId;
	private String showName;
	private String location;
	private Date date;
	private int avlSeats;
	private double price;
	
	public ShowDetails()
	{
		super();
		// TODO Auto-generated constructor stub
	}

	public ShowDetails(String showId, String showName, String location, Date date,
			int avlSeats, double price) {
		super();
		this.showId = showId;
		this.showName = showName;
		this.location = location;
		this.date = date;
		this.avlSeats = avlSeats;
		this.price = price;
	}

	public String getShowId() {
		return showId;
	}

	public void setShowId(String showId) {
		this.showId = showId;
	}

	public String getShowName() {
		return showName;
	}

	public void setShowName(String showName) {
		this.showName = showName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public int getAvlSeats() {
		return avlSeats;
	}

	public void setAvlSeats(int avlSeats) {
		this.avlSeats = avlSeats;
	}

	public double getPrice() {
		return price;
	}

	@Override
	public String toString() {
		return "ShowDetails [showId=" + showId + ", showName=" + showName
				+ ", location=" + location + ", date=" + date + ", avlSeats="
				+ avlSeats + ", price=" + price + "]";
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	
	
	
	
	
	
	
}
