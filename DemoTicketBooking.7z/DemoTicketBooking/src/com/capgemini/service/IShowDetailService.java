package com.capgemini.service;

import java.util.List;

import com.capgemini.dto.ShowDetails;
import com.capgemini.exception.ShowDetailException;

public interface IShowDetailService
{
	

	  List<ShowDetails> getShowDetails() throws ShowDetailException;
	  
	 public  ShowDetails getShowDetails(String showId) throws ShowDetailException;
	 
	 public void ShowDetails(int seats,String showName)throws ShowDetailException;

}
