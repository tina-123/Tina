package com.capgemini.service;

import java.util.List;

import com.capgemini.Dao.IShowDetailsDao;
import com.capgemini.Dao.ShowDetailsdaoImpl;
import com.capgemini.dto.*;

public class ShowDetailServiceImpl implements IShowDetailService {

	
	IShowDetailsDao showddetailsDao;
	
	public ShowDetailServiceImpl() 
	{
		showddetailsDao=new ShowDetailsdaoImpl();
	}

	@Override
	public List<ShowDetails> getShowDetails() 
	{
		System.out.println("in service");
		return showddetailsDao.getShowDetails();
	}

	@Override
	public ShowDetails getShowDetails(String showId) {
		// TODO Auto-generated method stub
		return showddetailsDao.getShowDetails(showId);
	}

	@Override
	public void ShowDetails(int seats, String showName) {
		
		showddetailsDao.ShowDetails(seats, showName);

	}

}
