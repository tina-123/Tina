package com.capgemini.Dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.exception.ShowDetailException;
import com.capgemini.util.DBUtil;
import com.capgemini.dto.ShowDetails;



public class ShowDetailsdaoImpl implements IShowDetailsDao 
{
	Connection con;
	Statement st;
	PreparedStatement pst;
	ResultSet res;

	@Override
	public List<ShowDetails> getShowDetails()
			throws ShowDetailException 
	{
		List<ShowDetails> sdList=new ArrayList<>();
		String sql="select * from ShowDetails";
		System.out.println("In dao");
		try 
		{
			con=DBUtil.getConnection();
			st=con.createStatement();
			res=st.executeQuery(sql);
			
			while(res.next())
			{
				ShowDetails showDetails=new ShowDetails();
				showDetails.setShowId(res.getString(1));
				showDetails.setShowName(res.getString(2));
				showDetails.setLocation(res.getString(3));
				showDetails.setDate(res.getDate(4));
				showDetails.setAvlSeats(res.getInt(5));
				showDetails.setPrice(res.getDouble(6));
				sdList.add(showDetails);
				
				
			}
			
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		return sdList;
	}

	@Override
	public ShowDetails getShowDetails(String showid) throws ShowDetailException 
	{
		ShowDetails show = null ;
		try
		{
			con = DBUtil.getConnection();
			pst = con.prepareStatement("select * from showdetails where showid=?");
			pst.setString(1, showid);
			res = pst.executeQuery() ;
			res.next() ;
			show = new ShowDetails() ;
			show.setShowId(res.getString(1));
			show.setShowName(res.getString(2));
			show.setLocation(res.getString(3));
			show.setDate(res.getDate(4));
			show.setAvlSeats(res.getInt(5));
			show.setPrice(res.getDouble(6));
			
			
		}
		catch(SQLException e)
		{
			//e.printStackTrace();
			throw new ShowDetailException ("Problem while fetching show details");
		}
	
		return show;
	}

	@Override
	public void ShowDetails(int seats , String showname) throws ShowDetailException 
	{
		try
		{
			con = DBUtil.getConnection() ;
			pst = con.prepareStatement("update showdetails set avseats = ? where showname = ?") ;
			pst.setInt(1, seats);
			pst.setString(2, showname);
			pst.executeUpdate();
		}
		catch(SQLException e)
		{
			//e.printStackTrace();
			throw new ShowDetailException ("Problem while updating the table");
		}
	}
	

	
}
