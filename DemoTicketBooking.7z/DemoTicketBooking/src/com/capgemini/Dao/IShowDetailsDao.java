package com.capgemini.Dao;

import java.util.List;

import com.capgemini.dto.ShowDetails;
import com.capgemini.exception.ShowDetailException;

public interface IShowDetailsDao

{
  List<ShowDetails> getShowDetails() throws ShowDetailException;
  
 public  ShowDetails getShowDetails(String showId) throws ShowDetailException;
 
 public void ShowDetails(int seats,String showName) throws ShowDetailException;
 
	
}
